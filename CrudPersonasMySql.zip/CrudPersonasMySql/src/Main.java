import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Main  extends JFrame {
    private JTextField nombreField;
    private JTextField apellidoField;
    private JTextField correoField;
    private JTable tablaPersonas;
    private DefaultTableModel tableModel;

    private final PersonaDAO personaDAO;

    public Main() {
        super("CRUD de Personas");
        personaDAO = new PersonaDAO();
        initializeUI();
        loadTableData();
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(4, 2));

        formPanel.add(new JLabel("Nombre:"));
        nombreField = new JTextField();
        formPanel.add(nombreField);
        formPanel.add(new JLabel("Apellido:"));
        apellidoField = new JTextField();
        formPanel.add(apellidoField);
        formPanel.add(new JLabel("Correo:"));
        correoField = new JTextField();
        formPanel.add(correoField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Agregar");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarPersona();
            }
        });
        buttonPanel.add(addButton);

        JButton updateButton = new JButton("Actualizar");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarPersona();
            }
        });
        buttonPanel.add(updateButton);

        JButton deleteButton = new JButton("Eliminar");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarPersona();
            }
        });
        buttonPanel.add(deleteButton);

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);

        // Configuración de la tabla
        tablaPersonas = new JTable();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Nombre");
        tableModel.addColumn("Apellido");
        tableModel.addColumn("Correo");
        tablaPersonas.setModel(tableModel);
        add(new JScrollPane(tablaPersonas), BorderLayout.AFTER_LAST_LINE);

        setSize(600, 600);
        setVisible(true);
    }

    private void loadTableData() {
        tableModel.setRowCount(0); // Limpiar la tabla antes de cargar nuevos datos

        List<Persona> personas = personaDAO.obtenerPersonas();
        for (Persona persona : personas) {
            Object[] rowData = {persona.getId(), persona.getNombre(), persona.getApellido(), persona.getCorreo()};
            tableModel.addRow(rowData);
        }
    }

    private void agregarPersona() {
        String nombre = nombreField.getText();
        String apellido = apellidoField.getText();
        String correo = correoField.getText();

        Persona persona = new Persona(nombre, apellido, correo);
        personaDAO.agregarPersona(persona);

        loadTableData();
    }

    private void actualizarPersona() {
        int filaSeleccionada = tablaPersonas.getSelectedRow();
        if (filaSeleccionada != -1) {
            int id = (int) tablaPersonas.getValueAt(filaSeleccionada, 0);
            String nombre = nombreField.getText();
            String apellido = apellidoField.getText();
            String correo = correoField.getText();

            Persona persona = new Persona(id, nombre, apellido, correo);
            personaDAO.actualizarPersona(persona);

            loadTableData();
        } else {
            JOptionPane.showMessageDialog(this, "Por favor seleccione una persona para actualizar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarPersona() {
        int filaSeleccionada = tablaPersonas.getSelectedRow();
        if (filaSeleccionada != -1) {
            int id = (int) tablaPersonas.getValueAt(filaSeleccionada, 0);
            personaDAO.eliminarPersona(id);
            loadTableData();
        } else {
            JOptionPane.showMessageDialog(this, "Por favor seleccione una persona para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main();
            }
        });
    }
}